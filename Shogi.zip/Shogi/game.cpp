#include "game.h"

void game::start()
{
    int testtest[2] = {7,23};

    Stukken test;
    test.ToString();
    test.SetLocatie(testtest);
    test.ToString();

}

game::game()
{

}


