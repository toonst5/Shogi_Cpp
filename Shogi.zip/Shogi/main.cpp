#include <iostream>
#include "game.h"

using namespace std;

int main()
{
    game test;
    cout << "Hello World!" << endl;
    test.start();
    return 0;
}
