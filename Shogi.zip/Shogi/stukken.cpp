#include "stukken.h"

int Stukken::Id = 0;

void Stukken::SetAll(std::string name, int Locatie, int speler)
{
    this -> name = name;
    *this -> Locatie = Locatie;
    this -> Speler = speler;

    Stukken::Id++;
}

Stukken::Stukken(std::string name, int Locatie, int speler)
{
    this -> name = name;
    *this -> Locatie = Locatie;
    this -> Speler = speler;

    Stukken::Id++;
}

Stukken::Stukken()
{
    this -> name = "";
    this -> Locatie[0] = 0;
    this -> Locatie[1] = 0;
    this -> Speler = 0;

    Stukken::Id++;
}

Stukken::~Stukken()
{
    std::cout << this -> name <<  this -> Speler <<  Stukken::Id << "vernietigt\n";

}

void Stukken::ToString()
{
    std::cout << this->name << "X" << this -> Locatie[0] << "\nY" << this -> Locatie[1] << "\n";
}
