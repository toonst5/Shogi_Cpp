#ifndef STUKKEN_H
#define STUKKEN_H
#include <string>
#include <iostream>

class Stukken
{
private:
    std::string name;
    int Locatie[2];
    int Speler;

    static int Id;

public:
    std::string GetName(){return name;}
    int* GetLocatie(){return this -> Locatie;}
    void SetLocatie(int Locatie[2]){this -> Locatie[0] = Locatie[0]; this -> Locatie[1] = Locatie[1];}

    void SetAll(std::string, int, int);
    Stukken(std::string, int, int);
    Stukken();
    ~Stukken();
    static int GetId(){return Id;}
    void ToString();
};

#endif // STUKKEN_H
