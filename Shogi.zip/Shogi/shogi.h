#ifndef SHOGI_H
#define SHOGI_H


class Shogi
{
public:
    Shogi();
};
#endif // SHOGI_H
