#ifndef PION_H
#define PION_H

#include <QGraphicsPolygonItem>

class pion: public QGraphicsPolygonItem
{
private:
    bool isPlaced;
    QString owner;
    int side0Attack;
    int side1Attack;
    int side2Attack;
    int side3Attack;
    int side4Attack;
    int side5Attack;

public:
    pion(QGraphicsItem* parent=NULL);

    int getAttackOf(int side);
    bool getIsPlaced();
    QString getOwner();

    void setAttackOf(int side, int attack);
    void setOwner(QString);
    void setIsPlaced(bool b);
};

#endif // PION_H
