#ifndef PION_H
#define PION_H

#include <QGraphicsPolygonItem>

class pion: public QGraphicsPolygonItem
{
private:
    QString owner;
    int side0Attack;
    int side1Attack;
    int side2Attack;
    int side3Attack;
    int side4Attack;
    int side5Attack;

public:
    pion(QGraphicsItem* parent=NULL);

    int getAttackOf(int side);

    void setAttackOf(int side, int attack);
};

#endif // PION_H
