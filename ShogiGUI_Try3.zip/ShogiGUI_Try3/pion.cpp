#include "pion.h"

pion::pion(QGraphicsItem* parent)
{
    QVector<QPointF> pentPoints;
    pentPoints << QPointF(0,10) << QPointF(1,2) << QPointF(4,0) << QPointF(7,2) << QPointF(8,10);

    int Scale_By = 8;
    for (size_t i = 0, n = pentPoints.size(); i<n; i++)
    {
        pentPoints[i] *= Scale_By;
    }

    QPolygonF pent(pentPoints);
    setPolygon(pent);
}

void pion::setOwner(QString player)
{
    owner = player;
}
