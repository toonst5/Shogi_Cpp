#include "board.h"
#include "game.h"

//extern game* Game;

board::board()
{

}

board::board(game* W)
{
    this->P=W;
}

QList<pion *> board::getPionen()
{
    return Pionen;
}

void board::placePionen(int x, int y, int cols, int rows)
{
    int X_SHIFT = 82;

        for (size_t i = 0, n = cols; i < n; i++)
        {

            creatPionColm(x+X_SHIFT*i,y,rows);
        }
}

void board::creatPionColm(int x, int y, int numPionen)
{
    for(size_t i=0; i<numPionen; i++)
    {
        pion* Pion = new pion();
        Pion->setPos(x,y+100*i);
        Pionen.append(Pion);
        P->scene->addItem(Pion);
    }
}
