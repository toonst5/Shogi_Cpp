#include "board.h"
#include "game.h"

//extern game* Game;

board::board()
{

}

board::board(game* W)
{
    this->P=W;
}

QList<pion *> board::getPionen()
{
    return Pionen;
}

void board::placePionen(int x, int y, int cols, int rows)
{
    int X_SHIFT = 82;
        int Y_SHIFT = 41;

        for (size_t i = 0, n = cols; i < n; i++){
            if (i % 2 == 0){ // even column
                Y_SHIFT = 0;
            }
            else{ // odd column
                Y_SHIFT = 41;
            }
            creatPionColm(x+X_SHIFT*i,y+Y_SHIFT,rows);
        }
}

void board::creatPionColm(int x, int y, int numPionen)
{
    for(size_t i=0; i<numPionen; i++)
    {
        pion* Pion = new pion();
        Pion->setPos(x,y+60*i);
        Pionen.append(Pion);
        P->scene->addItem(Pion);
    }
}
