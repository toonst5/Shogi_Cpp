#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include "board.h"

class game: public QGraphicsView
{
    Q_OBJECT

private:
    void drawPanel (int x, int y, int width, int hight, QColor color, double opacity);
    void drawGUI();
    QString whosTurn_;
    QGraphicsTextItem* whosTurnText;

public:
    game(QWidget* parent=NULL);
    void displayMainMenu();
    QGraphicsScene* scene;
    QString getWhosTurn();
    void setWhosTurn(QString player);

public slots:
    void start();
};

#endif // GAME_H
