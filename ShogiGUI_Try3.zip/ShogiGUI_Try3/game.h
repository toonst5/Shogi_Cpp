#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include "board.h"

class game: public QGraphicsView
{
    Q_OBJECT

private:
    void drawPanel (int x, int y, int width, int hight, QColor color, double opacity);
    void drawGUI();
    void createNewCard(QString player);
    void createInitialCards();
    void drawCards();

    QString whosTurn_;
    QGraphicsTextItem* whosTurnText;
    QList<pion*> player1Cards;
    QList<pion*> player2Cards;

public:
    game(QWidget* parent=NULL);
    void displayMainMenu();
    void setWhosTurn(QString player);
    QGraphicsScene* scene;
    QString getWhosTurn();


public slots:
    void start();
};

#endif // GAME_H
