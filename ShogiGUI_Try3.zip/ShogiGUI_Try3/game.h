#ifndef GAME_H
#define GAME_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include "board.h"

class game: public QGraphicsView
{
public:
    game(QWidget* parent=NULL);

    void start();

    QGraphicsScene* scene;
    //board* BOARD;
    QString whosTurn;
};

#endif // GAME_H
