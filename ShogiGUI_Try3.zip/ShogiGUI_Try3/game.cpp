#include "game.h"
#include "board.h"
#include "button.h"
#include <QGraphicsTextItem>


game::game(QWidget *parent)
{
    //set up the screen
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //setFixedSize(1024,768);
    setFixedSize(1900,1200);

    //set up scene
    scene = new QGraphicsScene();
    //scene->setSceneRect(0,0,1024,768);
    scene->setSceneRect(0,0,1900,1200);
    setScene(scene);
}

void game::start()
{
    scene->clear();

    board* pionBoard = new board(this);
    pionBoard->placePionen(200,100,9,3);
    drawGUI();
    createInitialCards();
}

void game::displayMainMenu()
{
    QGraphicsTextItem* titleText = new QGraphicsTextItem(QString("shogi"));
    QFont titleFont("comic sans",50);
    titleText->setFont(titleFont);
    int txPos = this->width()/2 - titleText->boundingRect().width()/2;
    int tyPos = 150;
    titleText->setPos(txPos,tyPos);
    scene->addItem(titleText);

    Button* playButton = new Button(QString("Play"));
    int bxPos = this->width()/2 - playButton->boundingRect().width()/2;
    int byPos = 275;
    playButton->setPos(bxPos,byPos);
    connect(playButton,SIGNAL(clicked()),this,SLOT(start()));
    scene->addItem(playButton);

    Button* quitButton = new Button(QString("Quit"));
    int qxPos = this->width()/2 - quitButton->boundingRect().width()/2;
    int qyPos = 350;
    quitButton->setPos(qxPos,qyPos);
    connect(quitButton,SIGNAL(clicked()),this,SLOT(close()));
    scene->addItem(quitButton);
}


void game::drawPanel(int x, int y, int width, int hight, QColor color, double opacity)
{
    QGraphicsRectItem* panal = new QGraphicsRectItem(x,y,width,hight);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(color);
    panal->setBrush(brush);
    panal->setOpacity(opacity);
    scene->addItem(panal);
}

void game::drawGUI()
{
   drawPanel(0,0,150,768,Qt::darkCyan,1);

   drawPanel(874,0,150,768,Qt::darkCyan,1);

   QGraphicsTextItem* p1= new QGraphicsTextItem("player 1's pieces: ");
   p1->setPos(25,0);
   scene->addItem(p1);

   QGraphicsTextItem* p2= new QGraphicsTextItem("player 2's pieces: ");
   p2->setPos(874+25,0);
   scene->addItem(p2);

   whosTurnText = new QGraphicsTextItem();
   setWhosTurn(QString("PLAYER1"));
   whosTurnText->setPos(490,0);
   scene->addItem(whosTurnText);
}

QString game::getWhosTurn()
{
    return whosTurn_;
}

void game::setWhosTurn(QString player)
{
    whosTurn_ = player;
    whosTurnText->setPlainText(QString("Whos Turn: ")+player);
}

void game::createNewCard(QString player)
{
    pion* Pion = new pion();
    Pion->setOwner(player);

    if(player == QString("PLAYER1"))
    {
        player1Cards.append(Pion);
    }else
    {
        player2Cards.append(Pion);
    }
    drawCards();
}

void game::createInitialCards()
{
    for(size_t i=0, n=5; i<n; i++)
    {
        createNewCard(QString("PLAYER1"));
    }

    for(size_t i=0, n=5; i<n; i++)
    {
        createNewCard(QString("PLAYER2"));
    }

    drawCards();
}

void game::drawCards()
{
    for(size_t i=0, n = player1Cards.size(); i<n; i++)
    {
        scene->removeItem(player1Cards[i]);
    }

    for(size_t i=0, n = player2Cards.size(); i<n; i++)
    {
        scene->removeItem(player2Cards[i]);
    }

    for (size_t i = 0, n = player1Cards.size(); i < n; i++)
    {
        pion* Pion = player1Cards[i];
        Pion->setPos(13,25+85*i);
        scene->addItem(Pion);
    }

    for (size_t i = 0, n = player2Cards.size(); i < n; i++){
        pion* Pion = player2Cards[i];
        Pion->setPos(874+13,25+85*i);
         scene->addItem(Pion);
    }
}

