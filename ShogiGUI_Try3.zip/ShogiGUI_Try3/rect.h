#ifndef RECT_H
#define RECT_H

#include <QGraphicsRectItem>

class rect: public QGraphicsPolygonItem
{
private:

public:
    rect();
};
#endif // RECT_H
