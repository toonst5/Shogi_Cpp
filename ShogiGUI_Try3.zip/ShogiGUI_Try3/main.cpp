#include <QApplication>
#include "game.h"

//game* Game;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    game* w = new game();
    w->show();
    w->start();
    return a.exec();
}
