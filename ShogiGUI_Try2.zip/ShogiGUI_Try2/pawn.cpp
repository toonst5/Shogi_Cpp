#include "pawn.h"

Pawn::Pawn()
{

}

Pawn::Pawn(char c, int x, int y, int s)
{
    SetAll(c,x,y,s,false);
}
