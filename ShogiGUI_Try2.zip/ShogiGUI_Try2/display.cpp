#include "display.h"
#include <QApplication>
#include <QGraphicsScene>
#include "mybord.h"
#include <QGraphicsView>
#include <QGraphicsPolygonItem>
#include <QGraphicsTextItem>

display::display()
{

}

void display::GUI(Stukken* oboy[39])
{   
    QGraphicsScene * scene = new QGraphicsScene();
    int f = 1;

    MyBord * rect = new MyBord();
    rect->setRect(5*f,5*f,90*f,90*f);
    scene->addItem(rect);
    rect->setFlag(QGraphicsItem::ItemIsFocusable);
    rect->setFocus();

    QGraphicsRectItem * rect1 = new QGraphicsRectItem();
    rect1->setRect(0*f,0*f,900*f,900*f);
    scene->addItem(rect1);

    QGraphicsRectItem * rect2 = new QGraphicsRectItem();
    rect2->setRect(-210*f,0*f,200*f,700*f);
    scene->addItem(rect2);

    QGraphicsRectItem * rect3 = new QGraphicsRectItem();
    rect3->setRect(910*f,200*f,200*f,700*f);
    scene->addItem(rect3);

    {
        QGraphicsLineItem * line1 = new QGraphicsLineItem(0,100,900,100);
        scene->addItem(line1);

        QGraphicsLineItem * line2 = new QGraphicsLineItem(0,200,900,200);
        scene->addItem(line2);

        QGraphicsLineItem * line3 = new QGraphicsLineItem(0,300,900,300);
        scene->addItem(line3);

        QGraphicsLineItem * line4 = new QGraphicsLineItem(0,400,900,400);
        scene->addItem(line4);

        QGraphicsLineItem * line5 = new QGraphicsLineItem(0,500,900,500);
        scene->addItem(line5);

        QGraphicsLineItem * line6 = new QGraphicsLineItem(0,600,900,600);
        scene->addItem(line6);

        QGraphicsLineItem * line7 = new QGraphicsLineItem(0,700,900,700);
        scene->addItem(line7);

        QGraphicsLineItem * line8 = new QGraphicsLineItem(0,800,900,800);
        scene->addItem(line8);

        //----------------------------------------------------------------------------------------------

        QGraphicsLineItem * line11 = new QGraphicsLineItem(100,0,100,900);
        scene->addItem(line11);

        QGraphicsLineItem * line12 = new QGraphicsLineItem(200,0,200,900);
        scene->addItem(line12);

        QGraphicsLineItem * line13 = new QGraphicsLineItem(300,0,300,900);
        scene->addItem(line13);

        QGraphicsLineItem * line14 = new QGraphicsLineItem(400,0,400,900);
        scene->addItem(line14);

        QGraphicsLineItem * line15 = new QGraphicsLineItem(500,0,500,900);
        scene->addItem(line15);

        QGraphicsLineItem * line16 = new QGraphicsLineItem(600,0,600,900);
        scene->addItem(line16);

        QGraphicsLineItem * line17 = new QGraphicsLineItem(700,0,700,900);
        scene->addItem(line17);

        QGraphicsLineItem * line18 = new QGraphicsLineItem(800,0,800,900);
        scene->addItem(line18);
    }



    QGraphicsView * view = new QGraphicsView(scene);

    {
        QGraphicsRectItem* stuk0 = new QGraphicsRectItem();
        stuk0->setRect(oboy[0]->GetLocatieX()*100 +10,oboy[0]->GetLocatieY()*100 +10,80,80);
        if(oboy[0]->GetSelect())
        {
            stuk0->setBrush(Qt::cyan);
        }else
        {
            stuk0->setBrush(Qt::NoBrush);
        }
        scene->addItem(stuk0);
        QGraphicsTextItem* stuk0T = new QGraphicsTextItem();
        stuk0T->setPlainText("hallo");
        stuk0T->setPos(oboy[0]->GetLocatieX()*100 + 35,oboy[0]->GetLocatieY()*100 + 35);
        scene->addItem(stuk0T);

        QGraphicsRectItem* stuk1 = new QGraphicsRectItem();
        stuk1->setRect(110,110,80,80);
        scene->addItem(stuk1);
    }


    view->show();

    if(rect->getStat())
    {
        for(int i=0;i<40;i++)
        {
            if(oboy[i]->GetLocatieX()==rect->getY()&&oboy[i]->GetLocatieY()==rect->getX())
            {
                oboy[i]->SetSelect(true);
            }else
            {
                oboy[i]->SetSelect(false);
            }
        }
    }


    //--------------------------------------------------

    {
//    //std::cout << "halo";
//    QPainter bord(this);
//    QPen pen;
//    QBrush Brush;


//    Brush.setColor(QColor(194, 145, 10, 200));
//    Brush.setStyle(Qt::SolidPattern);
//    bord.setBrush(Brush);

//    int xScherm = ((110 + 180 )/ 110);
//    int yScherm = ((91)/ 91);
//    if(xScherm > yScherm)
//    {
//        f = yScherm;
//    }else
//    {
//        f = xScherm;
//    }

//    //std::cout << y << x << f;

//    pen.setWidth(2);
//    bord.setPen(pen);
//    bord.setBrush(Brush);

//    bord.drawRoundRect(QRect(17*f,1*f,90*f,90*f),5,5);
//    bord.drawRoundRect(QRect(1*f,1*f,15*f,70*f),20,5);
//    bord.drawRoundRect(QRect(108*f,21*f,15*f,70*f),20,5);

//    QPainter bordLine(this);

//    pen.setWidth(1);
//    bordLine.setPen(pen);
//    for(int i = 0; i < 8 ; i++)
//    {
//        bordLine.drawLine((27+i*10)*f,1*f,(27+i*10)*f,91*f);
//        bordLine.drawLine(17*f,(11+i*10)*f,107*f,(11+i*10)*f);
//    }

//    QPainter bordCircle(this);

//    pen.setWidth(1);
//    bordCircle.setPen(pen);
//     Brush.setColor(Qt::black);
//    bordCircle.setBrush(Brush);

//    int startAngle = 0 * 16;
//    int spanAngle = 360 * 16;
//    QRectF rectangle(46.5*f, 30.5*f, 1*f, 1*f);
//    bordCircle.drawChord(rectangle, startAngle, spanAngle);

//    rectangle = QRectF(76.5*f, 30.5*f, 1*f, 1*f);
//    bordCircle.drawChord(rectangle, startAngle, spanAngle);

//    rectangle = QRectF(46.5*f, 60.5*f, 1*f, 1*f);
//    bordCircle.drawChord(rectangle, startAngle, spanAngle);

//    rectangle = QRectF(76.5*f, 60.5*f, 1*f, 1*f);
//    bordCircle.drawChord(rectangle, startAngle, spanAngle);

//    QPainter pion(this);
//    QPointF points[5];
//    int x;
//    int y;
//    for(int id=0;id<40;id++)
//    {
//        x = (xAR[id]*10);
//        y = (yAR[id]*10);

//        if(id<20)
//        {
//                points[0]=QPointF((18+x)*f,(2+y)*f);
//                points[1]=QPointF((19+x)*f,(9+y)*f);
//                points[2]=QPointF((22+x)*f,(10+y)*f);
//                points[3]=QPointF((25+x)*f,(9+y)*f);
//                points[4]=QPointF((26+x)*f,(2+y)*f);
//                Brush.setColor(QColor(200, 150, 100, 250));
//        }else
//        {
//                points[0]=QPointF((18+x)*f,(10+y)*f);
//                points[1]=QPointF((19+x)*f,(3+y)*f);
//                points[2]=QPointF((22+x)*f,(2+y)*f);
//                points[3]=QPointF((25+x)*f,(3+y)*f);
//                points[4]=QPointF((26+x)*f,(10+y)*f);
//                Brush.setColor(QColor(250, 200, 150, 250));
//        }

//        QPainter painter(this);
//        Brush.setStyle(Qt::SolidPattern);
//        painter.setBrush(Brush);
//        painter.drawConvexPolygon(points, 5);


//        QFont font;
//        font.setPixelSize(3*f);
//        pion.setFont(font);
//        if(name[id]=='P')
//        {
//           pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"歩\n兵");
//        }else if(name[id]=='B')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"角\n行");
//        }else if(name[id]=='R')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"飛\n車");
//        }else if(name[id]=='L')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"香\n車");
//        }else if(name[id]=='K')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"王\n將");
//        }else if(name[id]=='S')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"銀\n將");
//        }else if(name[id]=='G')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"金\n將");
//        }else if(name[id]=='N')
//        {
//            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"桂\n馬");
//        }

//    }
    }

}
