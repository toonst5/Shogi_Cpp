#include <QApplication>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QGraphicsView>
#include "game.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    game test;
    test.start();

    return a.exec();
}
