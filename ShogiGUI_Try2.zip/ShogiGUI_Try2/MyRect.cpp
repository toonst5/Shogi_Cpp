#include "MyRect.h"
#include <QKeyEvent>

void MyRect::keyPressEvent(QKeyEvent *event)
{


    if (event->key() == Qt::Key_Left)
    {
        setPos(x()-100,y());
    }else if (event->key() == Qt::Key_Right)
    {
        setPos(x()+100,y());
    }else if (event->key() == Qt::Key_Up)
    {
        setPos(x(),y()-100);
    }else if (event->key() == Qt::Key_Down)
    {
        setPos(x(),y()+100);
    }else if (event->key() == Qt::Key_Enter)
    {
        stat = true;
    }

    // bound check
    if(x()<0)
    {
        setPos(0,y());
    }else if(x()>800)
    {
        setPos(800,y());
    }
    if(y()<0)
    {
        setPos(x(),0);
    }else if(y()>800)
    {
        setPos(x(),800);
    }

    xPos = (x()-5)/100;
    yPos = (y()-5)/100;

}
