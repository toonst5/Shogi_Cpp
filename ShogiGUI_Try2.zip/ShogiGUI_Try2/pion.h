#ifndef PION_H
#define PION_H

#include <QGraphicsRectItem>

class pion: public QGraphicsRectItem
{
public:
    pion();
};

#endif // PION_H
