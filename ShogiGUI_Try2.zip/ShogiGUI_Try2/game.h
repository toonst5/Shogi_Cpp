#ifndef GAME_H
#define GAME_H

#include "stukken.h"



class game
{
private:

public:
    game();
    void start();
};

#endif // GAME_H

