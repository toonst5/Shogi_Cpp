#ifndef MYBORD_H
#define MYBORD_H

#include <QGraphicsRectItem>
#include "stukken.h"

class MyBord: public QGraphicsRectItem{
private:
    bool stat;
    int xPos;
    int yPos;
    static Stukken* oboy;
public:
    void keyPressEvent(QKeyEvent * event);
    bool getStat(){return stat;}
    int getX(){return xPos;}
    int getY(){return yPos;}
    //void setS(Stukken i[39]){oboy = i;}
};

#endif // MYBORD_H
