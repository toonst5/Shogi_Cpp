#ifndef PAWN_H
#define PAWN_H

#include "stukken.h"

class Pawn : public Stukken
{
private:
    std::string nam = "Pawn";

public:
    Pawn();
    Pawn(char, int, int,int);
    bool PosibleMove(int,int){return true;}
};

#endif // PAWN_H
