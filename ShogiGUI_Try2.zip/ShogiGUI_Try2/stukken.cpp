#include "stukken.h"
#include <QPixmap>
#include <QLabel>

int Stukken::Id=0;

void Stukken::SetAll(char name, int xIn,int yIn ,int speler, bool Select)
{
    this->name = name;
    this->xy.x = xIn;
    this->xy.y = yIn;
    this->Speler = speler;
    this->select = Select;
    Stukken::Id++;
}

Stukken::Stukken(char name, int xIn,int yIn , int speler)
{
    this->name = name;
    this->xy.x = xIn;
    this->xy.y = yIn;
    this->Speler = speler;
    this->select = false;
    Stukken::Id++;
}

Stukken::Stukken()
{
    this->name = ' ';
    this->xy.x = 0;
    this->xy.y = 0;
    this->Speler = 0;
    this->select = false;

    Stukken::Id++;
}

Stukken::~Stukken()
{
    std::cout << this -> name << "\nX" << this->xy.x << "       Y" << this->xy.y << "    id"<<  Stukken::Id << "\nvernietigt\n";

}

void Stukken::ToString()
{
    std::cout << this->name << "\nX" << this->xy.x << "\nY" << this->xy.y << "\n";
}
