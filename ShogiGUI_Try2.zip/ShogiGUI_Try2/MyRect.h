#ifndef MYRECT_H
#define MYRECT_H

#include <QGraphicsRectItem>

class MyRect: public QGraphicsRectItem{
private:
    bool stat;
    int xPos;
    int yPos;
public:
    void keyPressEvent(QKeyEvent * event);
    bool getStat(){return stat;}
    int getX(){return xPos;}
    int getY(){return yPos;}
};



#endif // MYRECT_H
