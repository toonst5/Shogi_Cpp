#include "pion.h"

pion::pion()
{
    setRect(0,0,10,10);
}
