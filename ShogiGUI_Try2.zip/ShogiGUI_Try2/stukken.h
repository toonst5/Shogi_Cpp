#ifndef STUKKEN_H
#define STUKKEN_H
#include <string>
#include <iostream>

struct cords{
    int x;
    int y;
    cords(int xIn = 0, int yIn = 0)
    {
        x = xIn;
        y = yIn;
    }
};

class Stukken
{
private:
    char name;
    struct cords xy;
    int Speler;
    static int Id;
    bool select;

public:
    bool virtual PosibleMove(int,int) = 0;
    char GetName(){return name;}
    int GetLocatieX(){return this->xy.x;}
    int GetLocatieY(){return this->xy.y;}
    bool GetSelect(){return this->select;}
    void SetLocatie(int xIn,int yIn){this->xy.x = xIn; this->xy.y = yIn;}
    void SetSelect(bool Select){this->select = Select;}

    void SetAll(char, int, int,int,bool);
    Stukken(char, int, int,int);
    Stukken();
    ~Stukken();
    int GetId(){return Id;}
    void ToString();
};

#endif // STUKKEN_H
