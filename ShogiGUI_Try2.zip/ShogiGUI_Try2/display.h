#ifndef DISPLAY_H
#define DISPLAY_H
#include "stukken.h"

class display
{
private:

public:
    display();
    void GUI(Stukken *[]);
};

#endif // DISPLAY_H
