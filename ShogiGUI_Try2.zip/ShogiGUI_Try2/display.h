#ifndef DISPLAY_H
#define DISPLAY_H


class display
{
public:
    display();
    void GUI();
};

#endif // DISPLAY_H
