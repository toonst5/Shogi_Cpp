#include "game.h"
#include <iostream>
//#include "stukken.h"
#include "pawn.h"
#include "display.h"


void game::start()
{

    Stukken* w0 = new Pawn('L',0,0,0);
    Stukken* w1 = new Pawn('N',1,0,0);
    Stukken* w2 = new Pawn('S',2,0,0);
    Stukken* w3 = new Pawn('G',3,0,0);
    Stukken* w4 = new Pawn('K',4,0,0);
    Stukken* w5 = new Pawn('G',5,0,0);
    Stukken* w6 = new Pawn('S',6,0,0);
    Stukken* w7 = new Pawn('N',7,0,0);
    Stukken* w8 = new Pawn('L',8,0,0);
    Stukken* w9 = new Pawn('P',0,2,0);;
    Stukken* w10 = new Pawn('P',1,2,0);
    Stukken* w11 = new Pawn('P',2,2,0);
    Stukken* w12 = new Pawn('P',3,2,0);
    Stukken* w13 = new Pawn('P',4,2,0);
    Stukken* w14 = new Pawn('P',5,2,0);
    Stukken* w15 = new Pawn('P',6,2,0);
    Stukken* w16 = new Pawn('P',7,2,0);
    Stukken* w17 = new Pawn('P',8,2,0);
    Stukken* w18 = new Pawn('R',1,1,0);
    Stukken* w19 = new Pawn('B',6,1,0);

    Stukken* b0 = new Pawn('P',0,6,1);
    Stukken* b1 = new Pawn('P',1,6,1);
    Stukken* b2 = new Pawn('P',2,6,1);
    Stukken* b3 = new Pawn('P',3,6,1);
    Stukken* b4 = new Pawn('P',4,6,1);
    Stukken* b5 = new Pawn('P',5,6,1);
    Stukken* b6 = new Pawn('P',6,6,1);
    Stukken* b7 = new Pawn('P',7,6,1);
    Stukken* b8 = new Pawn('P',8,6,1);
    Stukken* b9 = new Pawn('L',0,8,1);
    Stukken* b10 = new Pawn('N',1,8,1);
    Stukken* b11 = new Pawn('S',2,8,1);
    Stukken* b12 = new Pawn('G',3,8,1);
    Stukken* b13 = new Pawn('K',4,8,1);
    Stukken* b14 = new Pawn('G',5,8,1);
    Stukken* b15 = new Pawn('S',6,8,1);
    Stukken* b16 = new Pawn('N',7,8,1);
    Stukken* b17 = new Pawn('L',8,8,1);
    Stukken* b18 = new Pawn('B',1,7,1);
    Stukken* b19 = new Pawn('R',6,7,1);


    Stukken * pointers[40] ={};
    pointers[0]=w0;
    pointers[1]=w1;
    pointers[2]=w2;
    pointers[3]=w3;
    pointers[4]=w4;
    pointers[5]=w5;
    pointers[6]=w6;
    pointers[7]=w7;
    pointers[8]=w8;
    pointers[9]=w9;
    pointers[10]=w10;
    pointers[11]=w11;
    pointers[12]=w12;
    pointers[13]=w13;
    pointers[14]=w14;
    pointers[15]=w15;
    pointers[16]=w16;
    pointers[17]=w17;
    pointers[18]=w18;
    pointers[19]=w19;
    pointers[20]=b0;
    pointers[21]=b1;
    pointers[22]=b2;
    pointers[23]=b3;
    pointers[24]=b4;
    pointers[25]=b5;
    pointers[26]=b6;
    pointers[27]=b7;
    pointers[28]=b8;
    pointers[29]=b9;
    pointers[30]=b10;
    pointers[31]=b11;
    pointers[32]=b12;
    pointers[33]=b13;
    pointers[34]=b14;
    pointers[35]=b15;
    pointers[36]=b16;
    pointers[37]=b17;
    pointers[38]=b18;
    pointers[39]=b19;

    display w;

    w.GUI(pointers);


}


game::game()
{

}
