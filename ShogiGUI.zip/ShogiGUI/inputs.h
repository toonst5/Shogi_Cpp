#ifndef INPUTS_H
#define INPUTS_H


class inputs : public QObject
{
public:
    bool eventFilter(QObject *obj, QEvent *event)override;
    inputs();
};

#endif // INPUTS_H
