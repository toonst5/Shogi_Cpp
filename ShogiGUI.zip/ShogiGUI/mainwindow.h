#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include "stukken.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void Prime(Stukken *,int);

    void test(QPaintEvent *event);

    virtual void paintEvent(QPaintEvent *event);
private slots:
    void on_lineEdit_editingFinished();

    void on_lineEdit_cursorPositionChanged(int arg1, int arg2);

private:
    Ui::MainWindow *ui;
    int xAR[40];
    int yAR[40];
    int speler[40];
    char name[40];
};
#endif // MAINWINDOW_H
