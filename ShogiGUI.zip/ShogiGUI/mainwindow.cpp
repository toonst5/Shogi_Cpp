#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iostream>
#include <QPixmap>
#include <QLabel>
#include "eventfilter.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    //std::cout << "halo";
    QPainter bord(this);
    QPen pen;
    QBrush Brush;


    Brush.setColor(QColor(194, 145, 10, 200));
    Brush.setStyle(Qt::SolidPattern);
    bord.setBrush(Brush);

    int xScherm = ((height() + 180 )/ 110);
    int yScherm = ((width())/ 91);
    int f = 0;
    if(xScherm > yScherm)
    {
        f = yScherm;
    }else
    {
        f = xScherm;
    }

    //std::cout << y << x << f;

    pen.setWidth(2);
    bord.setPen(pen);
    bord.setBrush(Brush);

    bord.drawRoundRect(QRect(17*f,1*f,90*f,90*f),5,5);
    bord.drawRoundRect(QRect(1*f,1*f,15*f,70*f),20,5);
    bord.drawRoundRect(QRect(108*f,21*f,15*f,70*f),20,5);

    QPainter bordLine(this);

    pen.setWidth(1);
    bordLine.setPen(pen);
    for(int i = 0; i < 8 ; i++)
    {
        bordLine.drawLine((27+i*10)*f,1*f,(27+i*10)*f,91*f);
        bordLine.drawLine(17*f,(11+i*10)*f,107*f,(11+i*10)*f);
    }

    QPainter bordCircle(this);

    pen.setWidth(1);
    bordCircle.setPen(pen);
     Brush.setColor(Qt::black);
    bordCircle.setBrush(Brush);

    int startAngle = 0 * 16;
    int spanAngle = 360 * 16;
    QRectF rectangle(46.5*f, 30.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(76.5*f, 30.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(46.5*f, 60.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(76.5*f, 60.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    QPainter pion(this);
    QPointF points[5];
    int x;
    int y;
    for(int id=0;id<40;id++)
    {
        x = (xAR[id]*10);
        y = (yAR[id]*10);

        if(id<20)
        {
                points[0]=QPointF((18+x)*f,(2+y)*f);
                points[1]=QPointF((19+x)*f,(9+y)*f);
                points[2]=QPointF((22+x)*f,(10+y)*f);
                points[3]=QPointF((25+x)*f,(9+y)*f);
                points[4]=QPointF((26+x)*f,(2+y)*f);
                Brush.setColor(QColor(200, 150, 100, 250));
        }else
        {
                points[0]=QPointF((18+x)*f,(10+y)*f);
                points[1]=QPointF((19+x)*f,(3+y)*f);
                points[2]=QPointF((22+x)*f,(2+y)*f);
                points[3]=QPointF((25+x)*f,(3+y)*f);
                points[4]=QPointF((26+x)*f,(10+y)*f);
                Brush.setColor(QColor(250, 200, 150, 250));
        }

        QPainter painter(this);
        Brush.setStyle(Qt::SolidPattern);
        painter.setBrush(Brush);
        painter.drawConvexPolygon(points, 5);


        QFont font;
        font.setPixelSize(3*f);
        pion.setFont(font);
        if(name[id]=='P')
        {
           pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"歩\n兵");
        }else if(name[id]=='B')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"角\n行");
        }else if(name[id]=='R')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"飛\n車");
        }else if(name[id]=='L')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"香\n車");
        }else if(name[id]=='K')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"王\n將");
        }else if(name[id]=='S')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"銀\n將");
        }else if(name[id]=='G')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"金\n將");
        }else if(name[id]=='N')
        {
            pion.drawText((20.5+x)*f,(2.5+y)*f,5*f,10*f,1,"桂\n馬");
        }

    }

}

void MainWindow::Prime(Stukken* in, int id)
{
    this->name[id] = in->GetName();
    this->xAR[id] = in->GetLocatieX();
    this->yAR[id] = in->GetLocatieY();
    this->speler[id] = 0;
}



void MainWindow::on_lineEdit_cursorPositionChanged(int arg1, int arg2)
{

}

void MainWindow::test(QPaintEvent *event)
{
    QPainter pion(this);
    pion.drawText(100,100,10,10,1,"歩\n兵");
}
