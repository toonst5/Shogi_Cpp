#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <string>
#include <iostream>
#include <QPixmap>
#include <QLabel>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter bord(this);
    QPen pen;
    QBrush Brush;


    Brush.setColor(QColor(194, 145, 10, 200));
    Brush.setStyle(Qt::SolidPattern);
    bord.setBrush(Brush);

    int x = (height() / 110);
    int y = (width()/ 91);
    int f = 0;
    if(x > y)
    {
        f = y;
    }else
    {
        f = x;
    }

    std::cout << y << x << f;

    pen.setWidth(2);
    bord.setPen(pen);
    bord.setBrush(Brush);

    bord.drawRoundRect(QRect(17*f,1*f,90*f,90*f),10,10);
    bord.drawRoundRect(QRect(1*f,1*f,15*f,70*f),20,5);
    bord.drawRoundRect(QRect(108*f,21*f,15*f,70*f),20,5);

    QPainter bordLine(this);

    pen.setWidth(1);
    bordLine.setPen(pen);
    for(int i = 0; i < 8 ; i++)
    {
        bordLine.drawLine((27+i*10)*f,1*f,(27+i*10)*f,91*f);
        bordLine.drawLine(17*f,(10+i*10)*f,107*f,(10+i*10)*f);
    }

    QPainter bordCircle(this);

    pen.setWidth(1);
    bordCircle.setPen(pen);
     Brush.setColor(Qt::black);
    bordCircle.setBrush(Brush);

    int startAngle = 0 * 16;
    int spanAngle = 360 * 16;
    QRectF rectangle(46.5*f, 29.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(76.5*f, 29.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(46.5*f, 59.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    rectangle = QRectF(76.5*f, 59.5*f, 1*f, 1*f);
    bordCircle.drawChord(rectangle, startAngle, spanAngle);

    QPainter pion(this);


    QPointF points[5] = {
        QPointF(18*f,19*f),
        QPointF(19*f,12*f),
        QPointF(22*f,11*f),
        QPointF(25*f,12*f),
        QPointF(26*f,19*f)
    };



    QPainter painter(this);
    Brush.setColor(QColor(250, 200, 150, 250));
    Brush.setStyle(Qt::SolidPattern);
    painter.setBrush(Brush);
    painter.drawConvexPolygon(points, 5);


    QFont font;
    font.setPixelSize(3*f);
    pion.setFont(font);
    pion.drawText(20.5*f,11.5*f,5*f,10*f,QPainter::Antialiasing,"王\n將");
}
