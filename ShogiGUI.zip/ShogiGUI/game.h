#ifndef GAME_H
#define GAME_H

#include "stukken.h"
#include "mainwindow.h"

class game
{
private:
    MainWindow w;

public:
    game();
    void start();
};

#endif // GAME_H
