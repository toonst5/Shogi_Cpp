#include "game.h"
#include <iostream>
#include "stukken.h"


void game::start()
{

    Stukken w0('L',0,0,0);
    Stukken w1('N',1,0,0);
    Stukken w2('S',2,0,0);
    Stukken w3('G',3,0,0);
    Stukken w4('K',4,0,0);
    Stukken w5('G',5,0,0);
    Stukken w6('S',6,0,0);
    Stukken w7('N',7,0,0);
    Stukken w8('L',8,0,0);
    Stukken w9('P',0,2,0);;
    Stukken w10('P',1,2,0);
    Stukken w11('P',2,2,0);
    Stukken w12('P',3,2,0);
    Stukken w13('P',4,2,0);
    Stukken w14('P',5,2,0);
    Stukken w15('P',6,2,0);
    Stukken w16('P',7,2,0);
    Stukken w17('P',8,2,0);
    Stukken w18('R',1,1,0);
    Stukken w19('B',6,1,0);

    Stukken b0('P',0,6,1);
    Stukken b1('P',1,6,1);
    Stukken b2('P',2,6,1);
    Stukken b3('P',3,6,1);
    Stukken b4('P',4,6,1);
    Stukken b5('P',5,6,1);
    Stukken b6('P',6,6,1);
    Stukken b7('P',7,6,1);
    Stukken b8('P',8,6,1);
    Stukken b9('L',0,8,1);
    Stukken b10('N',1,8,1);
    Stukken b11('S',2,8,1);
    Stukken b12('G',3,8,1);
    Stukken b13('K',4,8,1);
    Stukken b14('G',5,8,1);
    Stukken b15('S',6,8,1);
    Stukken b16('N',7,8,1);
    Stukken b17('L',8,8,1);
    Stukken b18('B',1,7,1);
    Stukken b19('R',6,7,1);


    w.Prime(&w0,0);
    w.Prime(&w1,1);
    w.Prime(&w2,2);
    w.Prime(&w3,3);
    w.Prime(&w4,4);
    w.Prime(&w5,5);
    w.Prime(&w6,6);
    w.Prime(&w7,7);
    w.Prime(&w8,8);
    w.Prime(&w9,9);
    w.Prime(&w10,10);
    w.Prime(&w11,11);
    w.Prime(&w12,12);
    w.Prime(&w13,13);
    w.Prime(&w14,14);
    w.Prime(&w15,15);
    w.Prime(&w16,16);
    w.Prime(&w17,17);
    w.Prime(&w18,18);
    w.Prime(&w19,19);



    w.Prime(&b0,20);
    w.Prime(&b1,21);
    w.Prime(&b2,22);
    w.Prime(&b3,23);
    w.Prime(&b4,24);
    w.Prime(&b5,25);
    w.Prime(&b6,26);
    w.Prime(&b7,27);
    w.Prime(&b8,28);
    w.Prime(&b9,29);
    w.Prime(&b10,30);
    w.Prime(&b11,31);
    w.Prime(&b12,32);
    w.Prime(&b13,33);
    w.Prime(&b14,34);
    w.Prime(&b15,35);
    w.Prime(&b16,36);
    w.Prime(&b17,37);
    w.Prime(&b18,38);
    w.Prime(&b19,39);

    w.resize(1100, 910);
    w.setWindowTitle("shogi");
    w.show();

}


game::game()
{

}
