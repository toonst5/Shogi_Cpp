#include "game.h"
#include <iostream>
#include "stukken.h"

void game::start()
{
    Stukken w0("pion",2,0,0);
    Stukken w1("pion",2,1,0);
    Stukken w2("pion",2,2,0);
    Stukken w3("pion",2,3,0);
    Stukken w4("pion",2,4,0);
    Stukken w5("pion",2,5,0);
    Stukken w6("pion",2,6,0);
    Stukken w7("pion",2,7,0);
    Stukken w8("pion",2,8,0);
    Stukken w9;
    Stukken w10;
    Stukken w11;
    Stukken w12;
    Stukken w13;
    Stukken w14;
    Stukken w15;
    Stukken w16;
    Stukken w17;
    Stukken w18;
    Stukken w19;

    Stukken b0("pion",6,0,1);
    Stukken b1("pion",6,1,1);
    Stukken b2("pion",6,2,1);
    Stukken b3("pion",6,3,1);
    Stukken b4("pion",6,4,1);
    Stukken b5("pion",6,5,1);
    Stukken b6("pion",6,6,1);
    Stukken b7("pion",6,7,1);
    Stukken b8("pion",6,8,1);
    Stukken b9;
    Stukken b10;
    Stukken b11;
    Stukken b12;
    Stukken b13;
    Stukken b14;
    Stukken b15;
    Stukken b16;
    Stukken b17;
    Stukken b18;
    Stukken b19;




}

game::game()
{

}
