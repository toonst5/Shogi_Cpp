#include "inputs.h"

inputs::inputs()
{

}
