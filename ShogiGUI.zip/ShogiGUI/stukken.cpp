#include "stukken.h"
#include <QPixmap>
#include <QLabel>
#include "mainwindow.h"
#include "ui_mainwindow.h"


void Stukken::SetAll(char name, int xIn,int yIn ,int speler)
{
    this->name = name;
    this->xy.x = xIn;
    this->xy.y = yIn;
    this->Speler = speler;

    Stukken::Id++;
}

Stukken::Stukken(char name, int xIn,int yIn , int speler)
{
    this->name = name;
    this->xy.x = xIn;
    this->xy.y = yIn;
    this->Speler = speler;

    Stukken::Id++;
}

Stukken::Stukken()
{
    this->name = ' ';
    this->xy.x = 0;
    this->xy.y = 0;
    this->Speler = 0;

    Stukken::Id++;
}

Stukken::~Stukken()
{
    std::cout << this -> name <<  this -> Speler <<  Stukken::Id << "vernietigt\n";

}

void Stukken::ToString()
{
    std::cout << this->name << "X" << this->xy.x << "\nY" << this->xy.y << "\n";
}
