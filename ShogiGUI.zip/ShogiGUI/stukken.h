#ifndef STUKKEN_H
#define STUKKEN_H
#include <string>
#include <iostream>

struct cords{
    int x;
    int y;
    cords(int xIn = 1, int yIn = 0)
    {
        x = xIn;
        y = yIn;
    }
};

class Stukken
{
private:
    std::string name;

    struct cords xy;

    int Speler;

    static int Id;

public:
    std::string GetName(){return name;}
    int GetLocatieX(){return this->xy.x;}
    int GetLocatieY(){return this->xy.y;}
    void SetLocatie(int xIn,int yIn){this->xy.x = xIn; this->xy.y = yIn;}

    void SetAll(std::string, int, int,int);
    Stukken(std::string, int, int,int);
    Stukken();
    ~Stukken();
    static int GetId(){return Id;}
    void ToString();
};

#endif // STUKKEN_H
