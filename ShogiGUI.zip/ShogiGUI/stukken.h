#ifndef STUKKEN_H
#define STUKKEN_H
#include <string>
#include <iostream>

struct cords{
    int x;
    int y;
    cords(int xIn = 1, int yIn = 0)
    {
        x = xIn;
        y = yIn;
    }
};

class Stukken
{
private:
    char name;

    struct cords xy;

    int Speler;

    int Id;

public:
    char GetName(){return name;}
    int GetLocatieX(){return this->xy.x;}
    int GetLocatieY(){return this->xy.y;}
    void SetLocatie(int xIn,int yIn){this->xy.x = xIn; this->xy.y = yIn;}

    void SetAll(char, int, int,int);
    Stukken(char, int, int,int);
    Stukken();
    ~Stukken();
    int GetId(){return Id;}
    void ToString();
};

#endif // STUKKEN_H
