#ifndef EVENTFILTER_H
#define EVENTFILTER_H

#include <QObject>

class eventfilter : public QObject
{
    Q_OBJECT
public:
    using eventfilter_sig = std::function<bool(QObject*,QEvent*)>;
    explicit eventfilter(eventfilter_sig filter, QObject *parent = 0);

signals:

public slots:
protected:
    bool eventFilter(QObject *obj, QEvent *event);
    eventfilter_sig filter;

};

#endif // EVENTFILTER_H
