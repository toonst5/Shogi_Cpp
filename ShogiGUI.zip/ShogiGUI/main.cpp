#include "mainwindow.h"
#include "game.h"
#include <iostream>
#include <QPixmap>
#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);


    MainWindow w;
    w.resize(1100, 910);
    w.setWindowTitle("shogi");
    w.show();
    game test;
    test.start();
    return a.exec();


}
